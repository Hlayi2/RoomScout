namespace RoomScout.Views.AdminSide;

public partial class BookingRequestsPage : ContentPage
{
	public BookingRequestsPage()
	{
		InitializeComponent();
	}
}