namespace RoomScout.Views.AdminSide;

public partial class ManageListingsPage : ContentPage
{
	public ManageListingsPage()
	{
		InitializeComponent();
	}
}