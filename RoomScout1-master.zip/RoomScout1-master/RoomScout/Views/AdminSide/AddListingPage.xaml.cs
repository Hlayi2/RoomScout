namespace RoomScout.Views.AdminSide;

public partial class AddListingPage : ContentPage
{
	public AddListingPage()
	{
		InitializeComponent();
	}
}