namespace RoomScout.Views.AdminSide;

public partial class LandlordDashboardPage : ContentPage
{
	public LandlordDashboardPage()
	{
		InitializeComponent();
	}
}