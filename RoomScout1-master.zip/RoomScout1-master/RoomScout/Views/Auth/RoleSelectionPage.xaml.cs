namespace RoomScout.Views.Auth;

public partial class RoleSelectionPage : ContentPage
{
	public RoleSelectionPage()
	{
		InitializeComponent();
	}
}