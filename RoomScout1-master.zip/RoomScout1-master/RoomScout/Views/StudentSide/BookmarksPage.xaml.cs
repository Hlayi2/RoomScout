namespace RoomScout.Views.StudentSide;

public partial class BookmarksPage : ContentPage
{
	public BookmarksPage()
	{
		InitializeComponent();
	}
}