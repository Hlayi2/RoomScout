namespace RoomScout.Views.StudentSide;

public partial class BrowseListingsPage : ContentPage
{
	public BrowseListingsPage()
	{
		InitializeComponent();
	}
}