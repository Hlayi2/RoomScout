namespace RoomScout.Views.StudentSide;

public partial class BookingHistoryPage : ContentPage
{
	public BookingHistoryPage()
	{
		InitializeComponent();
	}
}