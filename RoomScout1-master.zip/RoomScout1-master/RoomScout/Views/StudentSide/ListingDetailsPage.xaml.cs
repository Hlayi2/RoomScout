namespace RoomScout.Views.StudentSide;

public partial class ListingDetailsPage : ContentPage
{
	public ListingDetailsPage()
	{
		InitializeComponent();
	}
}